#!/bin/bash

echo "  _   _  _____  _____  _____             _    _ _____ _____ _______ 	"
echo " | \ | |/ ____|/ ____|/ ____|       /\  | |  | |  __ \_   _|__   __|	"
echo " |  \| | |    | (___ | |           /  \ | |  | | |  | || |    | |   	"
echo ' | . ` | |     \___ \| |          / /\ \| |  | | |  | || |    | |   	'
echo " | |\  | |____ ____) | |____     / ____ \ |__| | |__| || |_   | |   	"
echo " |_| \_|\_____|_____/ \_____|   /_/    \_\____/|_____/_____|  |_|	  	"


echo ""
echo "###############################################################"
echo " Ensure /tmp is configured "
echo "###############################################################"
echo ""

findmnt -n /tmp
echo "---------------------------------------------------------------"
grep -E '\s/tmp\s' /etc/fstab | grep -E -v '^\s*#'
echo "---------------------------------------------------------------"
systemctl show "tmp.mount" | grep -i unitfilestate

echo ""
echo "###############################################################"
echo " Ensure /dev/shm is configured "
echo "###############################################################"
echo ""

findmnt -n /dev/shm
echo "---------------------------------------------------------------"
grep -E '\s/dev/shm\s' /etc/fstab

echo ""
echo "###############################################################"
echo " Ensure separate partition exists for /var "
echo "###############################################################"
echo ""

findmnt /var

echo ""
echo "###############################################################"
echo " Ensure separate partition exists for /var/tmp "
echo "###############################################################"
echo ""

findmnt /var/tmp

echo ""
echo "###############################################################"
echo " Ensure separate partition exists for /var/log "
echo "###############################################################"
echo ""

findmnt /var/log


echo ""
echo "###############################################################"
echo " Ensure separate partition exists for /home "
echo "###############################################################"
echo ""

findmnt /home

echo ""
echo "###############################################################"
echo " Ensure noexec option set on /tmp partition "
echo "###############################################################"
echo ""

findmnt -n /tmp | grep -Ev '\bnodev\b'
echo "Note: Nothing returned is passed "


echo ""
echo "###############################################################"
echo " Ensure nosuid option set on /tmp partition "
echo "###############################################################"
echo ""

findmnt -n /tmp -n | grep -Ev '\bnosuid\b'
echo "Note: Nothing returned is passed "

echo ""
echo "###############################################################"
echo " Ensure noexec option set on /dev/shm partition "
echo "###############################################################"
echo ""

findmnt -n /dev/shm | grep -Ev '\bnoexec\b'
echo "Note: Nothing returned is passed "

echo ""
echo "###############################################################"
echo " Ensure nosuid option set on /dev/shm partition "
echo "###############################################################"
echo ""

findmnt -n /dev/shm | grep -Ev '\bnosuid\b'
echo "Note: Nothing returned is passed "

echo ""
echo "###############################################################"
echo " Ensure /var/tmp partition includes the noexec option "
echo "###############################################################"
echo ""

findmnt -n /var/tmp | grep -Ev '\bnoexec\b'
echo "Note: Nothing returned is passed "


echo ""
echo "###############################################################"
echo " Ensure /var/tmp partition includes the nosuid option "
echo "###############################################################"
echo ""

findmnt -n /var/tmp | grep -Ev '\bnosuid\b'
echo "Note: Nothing returned is passed "


echo ""
echo "###############################################################"
echo " Ensure sticky bit is set on all world-writable directories "
echo "###############################################################"
echo ""

df --local -P 2> /dev/null | awk '{if (NR!=1) print $6}' | xargs -I '{}' find '{}' -xdev -type d \( -perm -0002 -a ! -perm -1000 \) 2>/dev/null
echo " Note: No output should be returned "

echo ""
echo "###############################################################"
echo " Disable Automounting "
echo "###############################################################"
echo ""

systemctl show "autofs.service" | grep -i unitfilestate=enabled
echo " Note: No output should be returned "

echo ""
echo "###############################################################"
echo " Disable USB Storage "
echo "###############################################################"
echo ""

modprobe -n -v usb-storage
echo "Note: install /bin/true"
echo "---------------------------------------------------------------"
lsmod | grep usb-storage
echo " Note: No output should be returned "

echo ""
echo "###############################################################"
echo " Ensure package manager repositories are configured "
echo "###############################################################"
echo ""

yum repolist

echo ""
echo "###############################################################"
echo " Ensure GPG keys are configured "
echo "###############################################################"
echo ""

rpm -q gpg-pubkey --qf '%{name}-%{version}-%{release} --> %{summary}\n'

echo ""
echo "###############################################################"
echo " Ensure gpgcheck is globally activated "
echo "###############################################################"
echo ""

grep ^\s*gpgcheck /etc/yum.conf
echo "---------------------------------------------------------------"
grep -P '^\h*gpgcheck=[^1\n\r]+\b(\h+.*)?$' /etc/yum.conf /etc/yum.repos.d/*.repo


echo ""
echo "###############################################################"
echo " Ensure permissions on bootloader config are configured "
echo "###############################################################"
echo ""

tst1="" tst2="" tst3="" tst4="" test1="" test2="" efidir="" gbdir=""
grubdir="" grubfile="" userfile=""
efidir=$(find /boot/efi/EFI/* -type d -not -name 'BOOT')
gbdir=$(find /boot -maxdepth 1 -type d -name 'grub*')
for file in "$efidir"/grub.cfg "$efidir"/grub.conf; do
	[ -f "$file" ] && grubdir="$efidir" && grubfile=$file
done
if [ -z "$grubdir" ]; then
	for file in "$gbdir"/grub.cfg "$gbdir"/grub.conf; do
		[ -f "$file" ] && grubdir="$gbdir" && grubfile=$file
done
fi
userfile="$grubdir/user.cfg"
stat -c "%a" "$grubfile" | grep -Pq '^\h*[0-7]00$' && tst1=pass 
output="Permissions on \"$grubfile\" are \"$(stat -c "%a" "$grubfile")\""
stat -c "%u:%g" "$grubfile" | grep -Pq '^\h*0:0$' && tst2=pass
output2="\"$grubfile\" is owned by \"$(stat -c "%U" "$grubfile")\" and belongs to group \"$(stat -c "%G" "$grubfile")\""
[ "$tst1" = pass ] && [ "$tst2" = pass ] && test1=pass
if [ -f "$userfile" ]; then
	stat -c "%a" "$userfile" | grep -Pq '^\h*[0-7]00$' && tst3=pass
	output3="Permissions on \"$userfile\" are \"$(stat -c "%a" "$userfile")\""
	stat -c "%u:%g" "$userfile" | grep -Pq '^\h*0:0$' && tst4=pass
	output4="\"$userfile\" is owned by \"$(stat -c "%U" "$userfile")\" and belongs to group \"$(stat -c "%G" "$userfile")\""
	[ "$tst3" = pass ] && [ "$tst4" = pass ] && test2=pass
else
	test2=pass
fi
[ "$test1" = pass ] && [ "$test2" = pass ] && passing=true
# If passing is true we pass
if [ "$passing" = true ] ; then
	echo "PASSED:"
	echo "$output"
	echo "$output2"
	[ -n "$output3" ] && echo "$output3"
	[ -n "$output4" ] && echo "$output4"
else
	# print the reason why we are failing
	echo "FAILED:"
	echo "$output"
	echo "$output2"
	[ -n "$output3" ] && echo "$output3"
	[ -n "$output4" ] && echo "$output4"
fi

echo ""
echo "###############################################################"
echo " Ensure bootloader password is set "
echo "###############################################################"
echo ""

tst1="" tst2="" output=""
efidir=$(find /boot/efi/EFI/* -type d -not -name 'BOOT')
gbdir=$(find /boot -maxdepth 1 -type d -name 'grub*')
if [ -f "$efidir"/grub.cfg ]; then
grubdir="$efidir" && grubfile="$efidir/grub.cfg"
elif [ -f "$gbdir"/grub.cfg ]; then
grubdir="$gbdir" && grubfile="$gbdir/grub.cfg"
fi
userfile="$grubdir/user.cfg"
[ -f "$userfile" ] && grep -Pq '^\h*GRUB2_PASSWORD\h*=\h*.+$' "$userfile" && output="\n PASSED: bootloader password set in \"$userfile\"\n\n"
if [ -z "$output" ] && [ -f "$grubfile" ]; then
grep -Piq '^\h*set\h+superusers\h*=\h*"?[^"\n\r]+"?(\h+.*)?$' "$grubfile" && tst1=pass
grep -Piq '^\h*password\h+\H+\h+.+$' "$grubfile" && tst2=pass
[ "$tst1" = pass ] && [ "$tst2" = pass ] && output="\n\n*** PASSED: bootloader password set in \"$grubfile\" ***\n\n"
fi
[ -n "$output" ] && echo -e "$output" || echo -e "\n\n *** FAILED: bootloader password is not set ***\n\n"

echo ""
echo "###############################################################"
echo " Ensure authentication required for single user mode "
echo "###############################################################"
echo ""

grep /sbin/sulogin /usr/lib/systemd/system/rescue.service
echo "---------------------------------------------------------------"
grep /sbin/sulogin /usr/lib/systemd/system/emergency.service

echo ""
echo "###############################################################"
echo " Ensure SELinux is installed "
echo "###############################################################"
echo ""

rpm -q libselinux

echo ""
echo "###############################################################"
echo " Ensure SELinux is not disabled in bootloader configuration "
echo "###############################################################"
echo ""

# IF check passes return PASSED
efidir=$(find /boot/efi/EFI/* -type d -not -name 'BOOT')
gbdir=$(find /boot -maxdepth 1 -type d -name 'grub*')
if [ -f "$efidir"/grub.cfg ]; then
	grep "^\s*linux" "$efidir"/grub.cfg | grep -Eq "(selinux=0|enforcing=0)" && echo "FAILED: \"$()\" exists" || echo "PASSED"
elif [ -f "$gbdir"/grub.cfg ]; then
	grep "^\s*linux" "$gbdir"/grub.cfg | grep -Eq "(selinux=0|enforcing=0)" && echo "FAILED: \"$()\" exists" || echo "PASSED"
else
echo "FAILED"
fi

echo ""
echo "###############################################################"
echo " Ensure SELinux policy is configured "
echo "###############################################################"
echo ""

grep SELINUXTYPE= /etc/selinux/config
echo "---------------------------------------------------------------"
sestatus | grep 'Loaded policy'

echo ""
echo "###############################################################"
echo " Ensure the SELinux mode is enforcing or permissive "
echo "###############################################################"
echo ""

getenforce
echo "---------------------------------------------------------------"
grep -Ei '^\s*SELINUX=(enforcing|permissive)' /etc/selinux/config

echo ""
echo "###############################################################"
echo " Ensure time synchronization is in use "
echo "###############################################################"
echo ""

rpm -q chrony ntp
echo "---------------------------------------------------------------"
rpm -q ntp

echo ""
echo "###############################################################"
echo " Ensure ntp is configured "
echo "###############################################################"
echo ""

systemctl is-enabled ntpd
echo "---------------------------------------------------------------"
grep "^restrict" /etc/ntp.conf
echo "---------------------------------------------------------------"
grep -E "^(server|pool)" /etc/ntp.conf

echo ""
echo "###############################################################"
echo " Ensure IP forwarding is disabled "
echo "###############################################################"
echo ""

sysctl net.ipv4.ip_forward
echo "---------------------------------------------------------------"
grep -E -s "^\s*net\.ipv4\.ip_forward\s*=\s*1" /etc/sysctl.conf /etc/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /run/sysctl.d/*.conf


echo ""
echo "###############################################################"
echo " Disable IPv6 "
echo "###############################################################"
echo ""

grep "^\s*linux" /boot/grub2/grub.cfg | grep -v ipv6.disable=1

echo ""
echo "###############################################################"
echo " Ensure TCP SYN Cookies is enabled "
echo "###############################################################"
echo ""

sysctl net.ipv4.tcp_syncookies
echo "---------------------------------------------------------------"
grep "net\.ipv4\.tcp_syncookies" /etc/sysctl.conf /etc/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /run/sysctl.d/*.conf

echo ""
echo "###############################################################"
echo " Ensure iptables(or nftables) is installed "
echo "###############################################################"
echo ""

rpm -q iptables iptables-services
echo "---------------------------------------------------------------"
rpm -q nftables

echo ""
echo "###############################################################"
echo " Ensure iptables(or nftables) default deny firewall policy "
echo "###############################################################"
echo ""

iptables -L
echo "---------------------------------------------------------------"
nft list ruleset | grep 'hook input'
echo "---------------------------------------------------------------"
nft list ruleset | grep 'hook forward'
echo "---------------------------------------------------------------"
nft list ruleset | grep 'hook output'

echo ""
echo "###############################################################"
echo " Ensure iptables(or nftables) is enabled and running "
echo "###############################################################"
echo ""

systemctl is-enabled iptables
echo "---------------------------------------------------------------"
systemctl is-enabled nftables

echo ""
echo "###############################################################"
echo " Ensure iptables(or nftables) rules are saved "
echo "###############################################################"
echo ""

cat /etc/sysconfig/iptables

echo ""
echo "###############################################################"
echo " Ensure auditd is installed "
echo "###############################################################"
echo ""

rpm -q audit audit-libs

echo ""
echo "###############################################################"
echo " Ensure auditd service is enabled and running "
echo "###############################################################"
echo ""

systemctl is-enabled auditd
echo "---------------------------------------------------------------"
systemctl status auditd | grep 'Active: active (running) '

echo ""
echo "###############################################################"
echo " Ensure auditing for processes that start prior to auditd is enabled "
echo "###############################################################"
echo ""

# IF check passes return PASSED
efidir=$(find /boot/efi/EFI/* -type d -not -name 'BOOT')
gbdir=$(find /boot -maxdepth 1 -type d -name 'grub*')
if [ -f "$efidir"/grub.cfg ]; then
	grep "^\s*linux" "$efidir"/grub.cfg | grep -Evq "audit=1\b" && echo "FAILED" || echo "PASSED"
elif [ -f "$gbdir"/grub.cfg ]; then
	grep "^\s*linux" "$gbdir"/grub.cfg | grep -Evq "audit=1\b" && echo "FAILED" || echo "PASSED"
else
	echo "FAILED"
fi

echo ""
echo "###############################################################"
echo " Ensure audit log storage size is configured "
echo "###############################################################"
echo ""

grep max_log_file /etc/audit/auditd.conf

echo ""
echo "###############################################################"
echo " Ensure audit logs are not automatically deleted "
echo "###############################################################"
echo ""

grep max_log_file_action /etc/audit/auditd.conf

echo ""
echo "###############################################################"
echo " Ensure system is disabled when audit logs are full "
echo "###############################################################"
echo ""

grep space_left_action /etc/audit/auditd.conf
echo "---------------------------------------------------------------"
grep action_mail_acct /etc/audit/auditd.conf
echo "---------------------------------------------------------------"
grep admin_space_left_action /etc/audit/auditd.conf


echo ""
echo "###############################################################"
echo "                   check config syslog server				     "
echo "###############################################################"
echo ""
cat /etc/rsyslog.conf

echo ""
echo "###############################################################"
echo " Ensure cron daemon is enabled and running "
echo "###############################################################"
echo ""

systemctl is-enabled crond
echo "---------------------------------------------------------------"
systemctl status crond | grep 'Active: active (running) '

echo ""
echo "###############################################################"
echo " Ensure permissions on /etc/crontab are configured "
echo "###############################################################"
echo ""

stat /etc/crontab

echo ""
echo "###############################################################"
echo " Ensure cron is restricted to authorized users "
echo "###############################################################"
echo ""

stat /etc/cron.deny
echo "---------------------------------------------------------------"
stat /etc/cron.allow

echo ""
echo "###############################################################"
echo " Ensure sudo is installed "
echo "###############################################################"
echo ""

rpm -q sudo

echo ""
echo "###############################################################"
echo " Ensure sudo commands use pty "
echo "###############################################################"
echo ""

grep -Ei '^\s*Defaults\s+([^#]\S+,\s*)?use_pty\b' /etc/sudoers /etc/sudoers.d/*
echo "Note: Defaults use_pty la pass"

echo ""
echo "###############################################################"
echo " Ensure sudo log file exists "
echo "###############################################################"
echo ""

grep -Ei '^\s*Defaults\s+([^#;]+,\s*)?logfile\s*=\s*(")?[^#;]+(")?' /etc/sudoers /etc/sudoers.d/*
echo "Note: Defaults logfile= /var/log/sudo.log is pass"

echo ""
echo "###############################################################"
echo " Ensure permissions on /etc/ssh/sshd_config are configured "
echo "###############################################################"
echo ""

stat /etc/ssh/sshd_config

echo ""
echo "###############################################################"
echo " Ensure permissions on SSH private host key files are configured "
echo "###############################################################"
echo ""

find /etc/ssh -xdev -type f -name 'ssh_host_*_key' -exec stat {} \;

echo ""
echo "###############################################################"
echo " Ensure permissions on SSH public host key files are configured "
echo "###############################################################"
echo ""

find /etc/ssh -xdev -type f -name 'ssh_host_*_key.pub' -exec stat {} \;

echo ""
echo "###############################################################"
echo " Ensure SSH access is limited "
echo "###############################################################"
echo ""

sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname) /etc/hosts | awk '{print $1}')" | grep -Pi '^\h*(allow|deny)(users|groups)\h+\H+(\h+.*)?$'
echo "---------------------------------------------------------------"
grep -Pi '^\h*(allow|deny)(users|groups)\h+\H+(\h+.*)?$' /etc/ssh/sshd_config

echo ""
echo "###############################################################"
echo " Ensure SSH root login is disabled "
echo "###############################################################"
echo ""

sshd -T -C user=root -C host="$(hostname)" -C addr="$(grep $(hostname) /etc/hosts | awk '{print $1}')" | grep permitrootlogin

echo ""
echo "###############################################################"
echo "                   check SSH config server				     "
echo "###############################################################"
echo ""
cat /etc/ssh/sshd_config 

echo ""
echo "###############################################################"
echo " Ensure password creation requirements are configured "
echo "###############################################################"
echo ""

grep '^\s*minlen\s*' /etc/security/pwquality.conf
echo "---------------------------------------------------------------"
grep '^\s*minclass\s*' /etc/security/pwquality.conf

echo ""
echo "###############################################################"
echo " Ensure lockout for failed password attempts is configured "
echo "###############################################################"
echo ""

grep -E '^\s*auth\s+\S+\s+pam_(faillock|unix)\.so' /etc/pam.d/system-auth /etc/pam.d/password-auth
echo "---------------------------------------------------------------"
grep -E '^\s*account\s+required\s+pam_faillock.so\s*' /etc/pam.d/systemauth /etc/pam.d/password-auth

echo ""
echo "###############################################################"
echo " Ensure password hashing algorithm is SHA-512 "
echo "###############################################################"
echo ""

grep -P '^\h*password\h+(sufficient|requisite|required)\h+pam_unix\.so\h+([^#\n\r]+)? sha512(\h+.*)?$' /etc/pam.d/system-auth /etc/pam.d/password-auth

echo ""
echo "###############################################################"
echo " Ensure password reuse is limited "
echo "###############################################################"
echo ""

grep -P '^\s*password\s+(requisite|required)\s+pam_pwhistory\.so\s+([^#]+\s+)*remember=([5-9]|[1-9][0-9]+)\b' /etc/pam.d/system-auth /etc/pam.d/password-auth

echo ""
echo "###############################################################"
echo " Ensure accounts in /etc/passwd use shadowed passwords "
echo "###############################################################"
echo ""

awk -F: '($2 != "x" ) { print $1 " is not set to shadowed passwords "}' /etc/passwd
echo "Note: Nothing returned is passed"

echo ""
echo "###############################################################"
echo " Ensure /etc/shadow password fields are not empty "
echo "###############################################################"
echo ""

awk -F: '($2 == "" ) { print $1 " does not have a password "}' /etc/shadow
echo "Note: Nothing returned is passed"

echo ""
echo "###############################################################"
echo " Ensure all groups in /etc/passwd exist in /etc/group "
echo "###############################################################"
echo ""

for i in $(cut -s -d: -f4 /etc/passwd | sort -u ); do
	grep -q -P "^.*?:[^:]*:$i:" /etc/group
	if [ $? -ne 0 ]; then
		echo "Group $i is referenced by /etc/passwd but does not exist in /etc/group"
	fi
done
echo "Note: Nothing returned is passed"

echo ""
echo "###############################################################"
echo " Ensure shadow group is empty "
echo "###############################################################"
echo ""

awk -F: '($1=="shadow") {print $NF}' /etc/group
echo "---------------------------------------------------------------"
awk -F: -v GID="$(awk -F: '($1=="shadow") {print $3}' /etc/group)" '($4==GID) {print $1}' /etc/passwd
echo "Note: Nothing returned is passed"

echo ""
echo "###############################################################"
echo " Ensure root is the only UID 0 account "
echo "###############################################################"
echo ""

awk -F: '($3 == 0) { print $1 }' /etc/passwd

echo ""
echo "###############################################################"
echo " Ensure root PATH Integrity "
echo "###############################################################"
echo ""

RPCV="$(sudo -Hiu root env | grep '^PATH' | cut -d= -f2)"
echo "$RPCV" | grep -q "::" && echo "root's path contains a empty directory (::)"
echo "$RPCV" | grep -q ":$" && echo "root's path contains a trailing (:)"
for x in $(echo "$RPCV" | tr ":" " "); do
	if [ -d "$x" ]; then
		ls -ldH "$x" | awk '$9 == "." {print "PATH contains current working directory (.)"}
		$3 != "root" {print $9, "is not owned by root"}
		substr($1,6,1) != "-" {print $9, "is group writable"}
		substr($1,9,1) != "-" {print $9, "is world writable"}'
	else
		echo "$x is not a directory"
	fi
done
echo "Note: Nothing returned is passed"

echo ""
echo "###############################################################"
echo " Ensure all users' home directories exist "
echo "###############################################################"
echo ""

awk -F: '($1!~/(halt|sync|shutdown|nfsnobody)/ && $7!~/^(\/usr)?\/sbin\/nologin(\/)?$/ && $7!~/(\/usr)?\/bin\/false(\/)?$/) { print $1 " " $6 }' /etc/passwd | while read -r user dir; do
	if [ ! -d "$dir" ]; then
		echo "User: \"$user\" home directory: \"$dir\" does not exist."
	fi
done
echo "Note: Nothing returned is passed"

echo ""
echo "###############################################################"
echo " Ensure users own their home directories "
echo "###############################################################"
echo ""

awk -F: '($1!~/(halt|sync|shutdown|nfsnobody)/ && $7!~/^(\/usr)?\/sbin\/nologin(\/)?$/ && $7!~/(\/usr)?\/bin\/false(\/)?$/) { print $1 " " $6 }' /etc/passwd | while read -r user dir; do
	if [ ! -d "$dir" ]; then
		echo "User: \"$user\" home directory: \"$dir\" does not exist."
	else
		owner=$(stat -L -c "%U" "$dir")
		if [ "$owner" != "$user" ]; then
			echo "User: \"$user\" home directory: \"$dir\" is owned by \"$owner\""
		fi
	fi
done
echo "Note: Nothing returned is passed"

echo ""
echo "###############################################################"
echo " Ensure users' home directories permissions are 750 or more restrictive "
echo "###############################################################"
echo ""

awk -F: '($1!~/(halt|sync|shutdown|nfsnobody)/ && $7!~/^(\/usr)?\/sbin\/nologin(\/)?$/ && $7!~/(\/usr)?\/bin\/false(\/)?$/) {print $1 " " $6}' /etc/passwd | while read -r user dir; do
	if [ ! -d "$dir" ]; then
		echo "User: \"$user\" home directory: \"$dir\" doesn't exist"
	else
		dirperm=$(stat -L -c "%A" "$dir")
		if [ "$(echo "$dirperm" | cut -c6)" != "-" ] || [ "$(echo "$dirperm" | cut -c8)" != "-" ] || [ "$(echo "$dirperm" | cut -c9)" != "-" ] || [ "$(echo "$dirperm" | cut -c10)" != "-" ]; then
			echo "User: \"$user\" home directory: \"$dir\" has permissions:\"$(stat -L -c "%a" "$dir")\""
		fi
	fi
done
echo "Note: Nothing returned is passed"

echo ""
echo "###############################################################"
echo " Ensure users' dot files are not group or world writable "
echo "###############################################################"
echo ""

awk -F: '($1!~/(halt|sync|shutdown|nfsnobody)/ && $7!~/^(\/usr)?\/sbin\/nologin(\/)?$/ && $7!~/(\/usr)?\/bin\/false(\/)?$/) { print $1 " " $6 }' /etc/passwd | while read -r user dir; do
	if [ -d "$dir" ]; then
		for file in "$dir"/.*; do
			if [ ! -h "$file" ] && [ -f "$file" ]; then
				fileperm=$(stat -L -c "%A" "$file")
				if [ "$(echo "$fileperm" | cut -c6)" != "-" ] || [ "$(echo "$fileperm" | cut -c9)" != "-" ]; then
					echo "User: \"$user\" file: \"$file\" has permissions:\"$fileperm\""
				fi
			fi
		done
	fi
done
echo "Note: Nothing returned is passed"


echo ""
echo "###############################################################"
echo " Ensure no users have .netrc files "
echo "###############################################################"
echo ""

awk -F: '($1!~/(halt|sync|shutdown|nfsnobody)/ && $7!~/^(\/usr)?\/sbin\/nologin(\/)?$/ && $7!~/(\/usr)?\/bin\/false(\/)?$/) { print $1 " " $6 }' /etc/passwd | while read -r user dir; do
	if [ -d "$dir" ]; then
		file="$dir/.netrc"
		if [ ! -h "$file" ] && [ -f "$file" ]; then
			if stat -L -c "%A" "$file" | cut -c4-10 | grep -Eq '[^-]+'; then
				echo "FAILED: User: \"$user\" file: \"$file\" exists with permissions: \"$(stat -L -c "%a" "$file")\", remove file or excessive permissions"
			else
				echo "WARNING: User: \"$user\" file: \"$file\" exists with permissions: \"$(stat -L -c "%a" "$file")\", remove file unless required"
			fi
		fi
	fi
done
echo "Note: FAILED: for any .netrc file with permissions less restrictive than 600"
echo "Note: WARNING: for any .netrc files that exist in interactive users' home directories."

echo ""
echo "###############################################################"
echo " Ensure no users have .rhosts files "
echo "###############################################################"
echo ""

awk -F: '($1!~/(root|halt|sync|shutdown|nfsnobody)/ && $7!~/^(\/usr)?\/sbin\/nologin(\/)?$/ && $7!~/(\/usr)?\/bin\/false(\/)?$/) { print $1 " " $6 }' /etc/passwd | while read -r user dir; do
	if [ -d "$dir" ]; then
		file="$dir/.rhosts"
		if [ ! -h "$file" ] && [ -f "$file" ]; then
			echo "User: \"$user\" file: \"$file\" exists"
		fi
	fi
done
echo "Note: Nothing returned is passed"

echo ""
echo "###############################################################"
echo " Ensure password expiration is 365 days or less "
echo "###############################################################"
echo ""

grep ^\s*PASS_MAX_DAYS /etc/login.defs

echo ""
echo "###############################################################"
echo " Ensure system accounts are secured "
echo "###############################################################"
echo ""

awk -F: '($1!="root" && $1!="sync" && $1!="shutdown" && $1!="halt" && $1!~/^\+/ && $3<'"$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)"' && $7!="'"$(which nologin)"'" && $7!="/bin/false") {print}' /etc/passwd
awk -F: '($1!="root" && $1!~/^\+/ && $3<'"$(awk '/^\s*UID_MIN/{print $2}' /etc/login.defs)"') {print $1}' /etc/passwd | xargs -I '{}' passwd -S '{}' |
awk '($2!="L" && $2!="LK") {print $1}'
echo "Note: Nothing returned is passed"

echo ""
echo "###############################################################"
echo " Ensure default group for the root account is GID 0 "
echo "###############################################################"
echo ""

grep "^root:" /etc/passwd | cut -f4 -d:

echo ""
echo "###############################################################"
echo " Ensure default user umask is configured "
echo "###############################################################"
echo ""

passing=""
grep -Eiq '^\s*UMASK\s+(0[0-7][2-7]7|[0-7][2-7]7)\b' /etc/login.defs && grep -Eqi '^\s*USERGROUPS_ENAB\s*"?no"?\b' /etc/login.defs && grep -Eq '^\s*session\s+(optional|requisite|required)\s+pam_umask\.so\b' /etc/pam.d/common-session && passing=true
grep -REiq '^\s*UMASK\s+\s*(0[0-7][2-7]7|[0-7][2-7]7|u=(r?|w?|x?)(r?|w?|x?)(r?|w?|x?),g=(r?x?|x?r?),o=)\b' /etc/profile* /etc/bashrc* && passing=true
[ "$passing" = true ] && echo "Default user umask is set"

echo ""
echo "###############################################################"
echo " Ensure default user shell timeout is configured "
echo "###############################################################"
echo ""

output1="" output2=""
[ -f /etc/bashrc ] && BRC="/etc/bashrc"
for f in "$BRC" /etc/profile /etc/profile.d/*.sh ; do
	grep -Pq '^\s*([^#]+\s+)?TMOUT=(900|[1-8][0-9][0-9]|[1-9][0-9]|[1-9])\b' "$f" && grep -Pq '^\s*([^#]+;\s*)?readonly\s+TMOUT(\s+|\s*;|\s*$|=(900|[1-8][0-9][0-9]|[1-9][0-9]|[1-9]))\b' "$f" && grep -Pq '^\s*([^#]+;\s*)?export\s+TMOUT(\s+|\s*;|\s*$|=(900|[1-8][0-9][0-9]|[1-9][0-9]|[1-9]))\b' "$f" && output1="$f"
done
grep -Pq '^\s*([^#]+\s+)?TMOUT=(9[0-9][1-9]|9[1-9][0-9]|0+|[1-9]\d{3,})\b' /etc/profile /etc/profile.d/*.sh "$BRC" && output2=$(grep -Ps '^\s*([^#]+\s+)?TMOUT=(9[0-9][1-9]|9[1-9][0-9]|0+|[1-9]\d{3,})\b' /etc/profile /etc/profile.d/*.sh $BRC)
if [ -n "$output1" ] && [ -z "$output2" ]; then
	echo -e "\nPASSED\n\nTMOUT is configured in: \"$output1\"\n"
else
	[ -z "$output1" ] && echo -e "\nFAILED\n\nTMOUT is not configured\n"
	[ -n "$output2" ] && echo -e "\nFAILED\n\nTMOUT is incorrectly configured in: \"$output2\"\n"
fi

echo ""
echo "###############################################################"
echo " Ensure root login is restricted to system console "
echo "###############################################################"
echo ""

cat /etc/securetty

echo ""
echo "###############################################################"
echo " Ensure permissions on /etc/passwd are configured "
echo "###############################################################"
echo ""

stat /etc/passwd

echo ""
echo "###############################################################"
echo " Ensure permissions on /etc/shadow are configured "
echo "###############################################################"
echo ""

stat /etc/shadow

echo ""
echo "###############################################################"
echo " Ensure permissions on /etc/gshadow are configured "
echo "###############################################################"
echo ""

stat /etc/gshadow

echo ""
echo "###############################################################"
echo " Ensure permissions on /etc/group are configured "
echo "###############################################################"
echo ""

stat /etc/group

echo ""
echo "###############################################################"
echo " Ensure no world writable files exist "
echo "###############################################################"
echo ""

df --local -P | awk '{if (NR!=1) print $6}' | xargs -I '{}' find '{}' -xdev -type f -perm -0002
echo "Note: Nothing returned is passed"

echo ""
echo "###############################################################"
echo " Audit SUID executables "
echo "###############################################################"
echo ""

df --local -P | awk '{if (NR!=1) print $6}' | xargs -I '{}' find '{}' -xdev -type f -perm -4000

echo ""
echo "###############################################################"
echo " Audit SGID executables "
echo "###############################################################"
echo ""

df --local -P | awk '{if (NR!=1) print $6}' | xargs -I '{}' find '{}' -xdev -type f -perm -2000
