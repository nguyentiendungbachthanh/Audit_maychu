#!/bin/bash

file=$(hostname -I).txt
newfile=$(echo "$file" | tr -d ' ')
chmod +x centos.sh
echo "Running....................."
./centos.sh > $newfile 2>&1
echo "Done"
